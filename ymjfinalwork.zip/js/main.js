const data = [
    { url:'../pic/slider01.jpg',title:''},
    { url:'../pic/slider02.jpg',title:''},
    { url:'../pic/slider03.jpg',title:''},
    { url:'../pic/slider04.jpg',title:''},
]
const img = document.querySelector('.slider-pic img')
const span = document.querySelector('.slider-character span')
//获取右侧按钮
const next = document.querySelector('.next')
let i = 0
next.addEventListener('click',function(){
    i++
    i = i >= data.length ? 0 : i
    toggle()
})
//获取左侧按钮
const prev = document.querySelector('.prev')
prev.addEventListener('click',function(){
    i--
    i = i < 0  ? data.length-1 : i
    toggle()
})
function toggle(){
    img.src = data[i].url
    span.innerHTML = data[i].title
    document.querySelector('.slider-indicator .my-active').classList.remove('my-active')
    document.querySelector(`.slider-indicator div:nth-child(${i+1})`).classList.add('my-active')
}
//自动播放
let timerId = setInterval(function(){
    //利用JS自动调用点击事件
    next.click()
},3000)
//鼠标经过大盒子停止定时器
const slider = document.querySelector('.slider')
slider.addEventListener('mouseenter',function(){
    clearInterval(timerId)
})
//鼠标离开大盒子开启定时器
slider.addEventListener('mouseleave',function(){
    clearInterval(timerId)
    timerId = setInterval(function(){
    //利用JS自动调用点击事件
    next.click()
},3000)
})