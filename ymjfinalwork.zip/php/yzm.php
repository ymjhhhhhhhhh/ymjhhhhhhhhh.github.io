<?php
session_start();
$image_width=100;
$image_height=25;
$num=range(0,9);
$character=range("Z","A");
$connect=array_merge($num,$character);
$string="";
$len=count($connect);
for($i=0;$i<4;$i++)
{
	$new[$i]=$connect[rand(0,$len-1)];
	
}
$image=imagecreatetruecolor($image_width,$image_height);
$white=imagecolorallocate($image,255,255,255);
$black=imagecolorallocate($image,0,0,0);
imagefill($image,0,0,$white);
for ($i=0;$i<10;$i++)
{
    $color=imagecolorallocate($image, rand(0,255), rand(0,255), rand(0,255));
    imageline($image, rand(0,100), rand(0,30), rand(0,100), rand(0,30), $color);
}
for($i=0;$i<100;$i++)
{
	imagesetpixel($image,rand(0,$image_width),rand(0,$image_height),$black);
}
for($i=0;$i<count($new);$i++)
{
	$x=mt_rand(1,8)+$image_width*$i/4;
	$y=mt_rand(1,$image_height/4);
	$color=imagecolorallocate($image,mt_rand(0,200),mt_rand(0,200),mt_rand(0,200));
	imagestring($image, 5, $x, $y, $new[$i], $color);
	$string=$string.$new[$i];
}
$_SESSION['yzm']=$string;
imagepng($image);
imagedestroy($image);
?>